import React,{useState, createContext} from 'react'

export const Consumer=createContext();
export function Provider(props) {
    const [task,setlist]=useState([
        {
            id:1,
            name:"Jhon",
            title:"Html/css Assignment",
            duration:"3 days",
            desc:"Duis lacinia sed ante sed dictum. Curabitur quis convallis enim. Nullam non felis maximus, vulputate orci at, vehicula sem."
        },
        {
            id:2,
            name:"William",
            title:"javascript Assignment",
            duration:"3 days",
            desc:"Sed turpis erat, congue nec pulvinar quis, interdum vel elit. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus facilisis sem id enim venenatis, a vulputate ligula condimentum. Aliquam vitae massa tortor."
        },
        {
            id:3,
            name:"James",
            title:"Jquery Assignment",
            duration:"2 days",
            desc:"Duis lacinia sed ante sed dictum. Curabitur quis convallis enim. Nullam non felis maximus, vulputate orci at, vehicula sem."
        },
        {
            id:4,
            name:"Jackson",
            title:"es6 Assignment",
            duration:"4 days",
            desc:"Sed turpis erat, congue nec pulvinar quis, interdum vel elit. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus facilisis sem id enim venenatis, a vulputate ligula condimentum. Aliquam vitae massa tortor."
        }, 
    ]);
    return (
        <Consumer.Provider value={[task,setlist]}>
            {props.children}
        </Consumer.Provider>
    )
}